export const SNACK_CHANGED = 'email_changed';
export const QUANTITY_CHANGED = 'quantity_changed';
export const UNITS_CHANGED = 'units_changed';
export const SEARCH_SUCCESS = 'search_success';
export const SEARCH_FAIL = 'search_fail';
export const SEARCH_SNACK = 'search_snack';
