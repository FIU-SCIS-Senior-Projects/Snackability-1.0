import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Table, TableWrapper, Row, Rows, Col } from 'react-native-table-component';
import { Divider } from 'react-native-elements';
import { connect } from 'react-redux';
import { snackSearchNdbno } from '../util';
import { Spinner } from './common';


export default class snackDetailView extends Component {

    constructor(props) {
        super(props);
        this.state = {

            calories: '',
            carbs: '',
            cholesterol: '',
            fiber: '',
            ingredients: {},
            protein: '',
            sodium: '',
            sugar: '',
            totalFat: '',
            transFat: '',
            tableHead: ['Nutrient', 'Value'],
            tableData: null
        }
    }


    componentWillMount() {

        snackSearchNdbno(this.props.snack.ndbno).then(
            snack => {

                const {
                    calories,
                    carbs,
                    cholesterol,
                    fiber,
                    ingredients,
                    protein,
                    sodium,
                    sugar,
                    totalFat,
                    transFat
                } = snack;



                const tableArray = [];

                Object.keys(snack).forEach(function (key, index) {
                    if (key !== 'ingredients') {
                        tableArray.push([key, snack[key]])
                    }
                });

                console.log(tableArray);


                this.setState({
                    calories,
                    carbs,
                    cholesterol,
                    fiber,
                    ingredients,
                    protein,
                    sodium,
                    sugar,
                    totalFat,
                    transFat,
                    tableData:tableArray
                });

            });

    }
    renderSnack() {


        const {
            calories,
            carbs,
            cholesterol,
            fiber,
            ingredients,
            protein,
            sodium,
            sugar,
            totalFat,
            transFat,
            tableData
        } = this.state;


        if (this.state.tableData === undefined || this.state.tableData == 0 || this.state.tableData===null) {
            return <Spinner size="large" />;
        }
        else {
            return (
                <View style={styles.container}>
                    <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                        <Row data={this.state.tableHead} style={styles.head} textStyle={styles.text} />
                        <Rows data={tableData} textStyle={styles.text} />
                    </Table>
                </View>
            );
        }
    }


    render() {
        return (
            <View style={{ flex: 1 }}>
                <Text style={styles.snackScore}>
                    Snack Score 7.0 😏
                </Text>
                <Text style={styles.feedBack}>
                    FeedBack: This snack is somewhat healthy, but could be better.
                </Text>
                <Divider style={{ backgroundColor: 'blue', marginBottom: 15 }} />
                {this.renderSnack()}


            </View>
        );
    }
}


const styles = StyleSheet.create({
    container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: '#fff' },
    head: { height: 40, backgroundColor: '#f1f8ff' },
    wrapper: { flexDirection: 'row' },
    title: { flex: 1, backgroundColor: '#f6f8fa' },
    row: { height: 28 },
    text: { textAlign: 'center' },
    snackScore: { textAlign: 'center', fontSize: 22, marginTop: 15, },
    feedBack: { textAlign: 'center', marginBottom: 10 }
});

