import React, { Component } from 'react';
import { Text, TouchableWithoutFeedback, View } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { CardSection } from './common';

class ListItem extends Component {

    onRowPress() {
        Actions.snackDetail({ snack: this.props.snack });
    }

    render() {
        const { name } = this.props.snack;

        const namez = name.substring(0, 40);

        return (
            <TouchableWithoutFeedback onPress={this.onRowPress.bind(this)}>
                <View>
                    <CardSection style={styles.sectionStyles}>
                        <Text style={styles.titleStyle}>
                            {namez}
                        </Text>
                    </CardSection>
                </View>
            </TouchableWithoutFeedback>
        );
    }
}

const styles = {
    titleStyle: {
        fontSize: 18,
        paddingLeft: 15
    },
    sectionStyles: {
        paddingLeft: 15,
        paddingLeft: 15,
        marginLeft: 7,
        marginRight: 7
    }
};

export default ListItem;
