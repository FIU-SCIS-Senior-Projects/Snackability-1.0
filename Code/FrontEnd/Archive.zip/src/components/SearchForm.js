import React, { Component } from 'react';
import { View, Text, TouchableOpacity, TouchableWithoutFeedback, UIManager, LayoutAnimation, Image } from 'react-native';
import { connect } from 'react-redux';
import { Dropdown } from 'react-native-material-dropdown';
import CheckBox from 'react-native-check-box'
import { Icon } from 'react-native-elements';
import logo from '../images/logo2.png';
import { snackChanged, quantityChanged, searchForSnack } from '../actions';

import { Card, CardSection, Input, Button, Spinner } from './common';
import SnackList from './SnackList';

class SearchForm extends Component {

    constructor(props) {
        super(props);
        this.state = {
            expandedSearch: false
        };
    }
    componentWillUpdate() {
        var CustomLayoutLinear = {
            duration: 200,
            create: {
                type: LayoutAnimation.Types.linear,
                property: LayoutAnimation.Properties.opacity,
            },
            update: {
                type: LayoutAnimation.Types.linear,
            },
        };

        UIManager.setLayoutAnimationEnabledExperimental && UIManager.setLayoutAnimationEnabledExperimental(true);
        LayoutAnimation.configureNext(CustomLayoutLinear);
    }

    toggleExpanded() {
        this.setState(previousState => {
            return { expandedSearch: !previousState.expandedSearch };
        });
    }

    onSnackChange(text) {
        this.props.snackChanged(text);
    }

    onQuantityChange(text) {
        this.props.quantityChanged(text);
    }

    onButtonPress() {
        const { snack, quantity } = this.props;
        this.props.searchForSnack({ snack, quantity });
    }

    renderButton() {

        if (this.props.loading) {
            return <Spinner size="large" />;
        }

        return (
            <Button onPress={this.onButtonPress.bind(this)}>
                Search
            </Button>
        );
    }

    renderResults() {
        if (this.props.snack_info) {

            if (this.props.snack_info === 'No results') {
             
                return <Text>{'No Results'}</Text>;

            }
            else {
                
                return <SnackList snacks={this.props.snack_info} />
            }
        }

        return <Text></Text>;
    }

    renderAdvancedSearch() {

        let units = [{
            value: 'g',
        }, {
            value: 'tbsp',
        }, {
            value: 'tsp',
        }, {
            value: 'oz'
        }, { value: 'kg' }
            ,
        { value: 'lbs' }
        ];

        let data = {
            checked: false
        }

        if (!this.state.expandedSearch) {

            return (
                <Card>
                    <CardSection>
                        <Input
                            label="🍓 Snack"
                            placeholder="Twix"
                            onChangeText={this.onSnackChange.bind(this)}
                            value={this.props.snack}
                        >
                            <TouchableOpacity
                                onPress={() => this.toggleExpanded()}
                                style={{ flex: 1 }}>
                                <Icon
                                    name='plus-circle'
                                    type='font-awesome'
                                    color='#007aff'
                                    size={20}
                                />
                            </TouchableOpacity>
                        </Input>
                    </CardSection>

                    <CardSection>
                        <Text style={styles.errorTextStyle}>
                            {this.props.error}
                        </Text>
                        {this.renderButton()}
                    </CardSection>
                </Card>
            );
        }
        else {
            return (
                <Card>
                    <CardSection>
                        <Input
                            label="🍓 Snack"
                            placeholder="Twix"
                            onChangeText={this.onSnackChange.bind(this)}
                            value={this.props.snack}
                        >
                            <TouchableOpacity
                                onPress={() => this.toggleExpanded()}
                                style={{ flex: 1 }}>
                                <Icon
                                    name='minus-circle'
                                    type='font-awesome'
                                    color='#007aff'
                                    size={20}
                                />
                            </TouchableOpacity>


                        </Input>
                    </CardSection>

                    <CardSection>
                        <Input
                            label="⚖️ Portion"
                            placeholder="20"
                            onChangeText={this.onQuantityChange.bind(this)}
                            style={{ marginRight: 85 }}
                            value={this.props.quantity}
                        >

                        </Input>

                    </CardSection>

                    <CardSection style={{
                        flexDirection: 'row',
                        alignItems: 'flex-end',
                        justifyContent: 'flex-end',
                        paddingTop: 0,
                        paddingBottom: 2,
                        paddingLeft: 5,
                        paddingRight: 5
                    }} >
                        <Dropdown
                            label='Units'
                            containerStyle={{ flex: 2, marginLeft: 10, paddingRight: 10, marginTop: 0 }}
                            data={units}
                        />
                        <CheckBox
                            style={{ flex: 1, marginBottom: 10 }}
                            onClick={() => this.onClick(data)}
                            isChecked={data.checked}
                            leftText={'Processed'}

                        />

                    </CardSection>


                    <CardSection>
                        <Text style={styles.errorTextStyle}>
                            {this.props.error}
                        </Text>
                        {this.renderButton()}
                    </CardSection>
                </Card>
            );
        }

    }

    render() {


        return (
            <View  style={{flex:1}}>
                <View style={styles.viewStyle}>
                    <Image
                        style={styles.imageStyle}
                        source={logo}
                    />
                    <Text style={styles.messageStyle}>
                        Tap the + or - icons to Toggle Advanced Search 
                    </Text>
                </View>
            <View style={{flex:1}}>
                    {this.renderAdvancedSearch()}
                    {this.renderResults()}
                </View>
            </View>
        );
    }

};

const styles = {
    errorTextStyle: {
        fontSize: 20,
        alignSelf: 'center',
        color: 'red'
    },
    viewStyle: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    imageStyle: {
        height: 125,
        width: 125,
        marginBottom: 10,
    },
    messageStyle: {
        fontWeight: 'bold',
        color:'#007aff',
        marginBottom: 10,
    }
};

const mapStateToProps = ({ search }) => {
    const { snack, quantity, error, loading, snack_info } = search;
    return { snack, quantity, error, loading, snack_info };
};

export default connect(mapStateToProps, {
    snackChanged, quantityChanged, searchForSnack
})(SearchForm);