import {
  SNACK_CHANGED,
  QUANTITY_CHANGED,
  UNITS_CHANGED,
  SEARCH_SNACK,
  SEARCH_SUCCESS,
  SEARCH_FAIL
} from '../actions/types';

const INITIAL_STATE = {
  snack: '',
  quantity: '',
  units: '',
  snack_info: '',
  error: '',
  loading: false
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case SNACK_CHANGED:
      return { ...state, snack: action.payload };
    case QUANTITY_CHANGED:
      return { ...state, quantity: action.payload };
    case SEARCH_SNACK:
      return {INITIAL_STATE, loading:true };
    case SEARCH_SUCCESS:
      return { ...state, ...INITIAL_STATE, snack_info: action.payload };
    case SEARCH_FAIL:
    console.log('search failed dispatch')
      return { ...INITIAL_STATE, snack_info: 'No results' };
    default:
      return state;
  }
};
