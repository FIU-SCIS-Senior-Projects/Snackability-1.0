import React from 'react';
import Expo from 'expo';
import { Scene, Router, Actions } from 'react-native-router-flux';
import SearchForm from './components/SearchForm';
import snackDetailView from './components/SnackDetailView';

const RouterComponent = () => (
    <Router  sceneStyle={{backgroundColor:'#ffffff'}} titleStyle={styles.titleStyle} navigationBarStyle={styles.navigationBarStyle}>
        <Scene key="main">
            <Scene key="snackSearch" component={SearchForm} title="Snack Search" init/>
            <Scene key="snackDetail" component={snackDetailView} title="Snack Detail"/>
        </Scene>
    </Router>



);
const styles= {
    titleStyle: {
        color: '#FFFFFF',
        fontWeight: 'bold',
        fontSize: 22,
        textAlign: 'center',
        alignSelf: 'center',
        paddingBottom: 10,
        marginTop: Expo.Constants.statusBarHeight,
    },
    navigationBarStyle:{
        backgroundColor:'#456ec5', 
        height:Expo.Constants.statusBarHeight+50
    }
}


export default RouterComponent;